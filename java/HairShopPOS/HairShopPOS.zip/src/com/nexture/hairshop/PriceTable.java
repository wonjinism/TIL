package com.nexture.hairshop;

public class PriceTable {
	static final int CUT = 4000;
	static final int PERM = 8300;
	static final int COLOR = 8800;
	static final int SHAMPOO = 500;
	static final int SCALPMASSAGE = 2500;
}
